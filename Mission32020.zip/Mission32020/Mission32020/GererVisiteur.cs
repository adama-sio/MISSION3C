﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mission32020
{
    public partial class GererVisiteur : Form
    {
        private mission2019Entities mesDonnees;
        public GererVisiteur(mission2019Entities mesDonnees)
        {
            InitializeComponent();
            this.mesDonnees = mesDonnees;

            /*var IdVisiteur = (from visiteur in mesDonnees.visiteur
                              select visiteur.id);
            comboBox1.DataSource = IdVisiteur.ToList();*/

            var LesVisiteurs = (from visiteur in mesDonnees.visiteur
                                select visiteur);

            dataGridView1.DataSource = LesVisiteurs.ToList();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            mesDonnees.SaveChanges();
            MessageBox.Show("Enregsitrer avec succès !");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AjouterVisiteur av = new AjouterVisiteur(this.mesDonnees);
            av.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SupprimerVisiteur sv = new SupprimerVisiteur(this.mesDonnees);
            sv.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GererVisiteur_Load(object sender, EventArgs e)
        {

        }

        private void ckbxModif_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbxModif.Checked == true)
            {
               ckbxModif.ForeColor = System.Drawing.Color.Firebrick;
                ckbxModif.Text = "Enregistrer ";
                dataGridView1.ReadOnly = false;
            }
            else
            {
                ckbxModif.Text = "Modifier";
                ckbxModif.ForeColor = System.Drawing.Color.Black ;
                mesDonnees.SaveChanges();
                MessageBox.Show("Enregsitrer avec succès !");
                dataGridView1.ReadOnly = true;
            }
        }
    }
}
