﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mission32020
{
    public partial class SupprimerVisiteur : Form
    {
        private mission2019Entities mesDonnees;
        public SupprimerVisiteur(mission2019Entities mesDonnees)
        {
            InitializeComponent();
            this.mesDonnees = mesDonnees;

            var getId = (from visiteur in mesDonnees.visiteur
                         select visiteur.id);

            

            idCombo.DataSource = getId.ToList();


            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void SupprimerVisiteur_Load(object sender, EventArgs e)
        {

        }

        private void idCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            string id = idCombo.Text;
            string idsupp = idCombo.SelectedItem.ToString();


            var rapp = (from v in mesDonnees.visiteur
                        join r in mesDonnees.rapport
                        on v.id equals r.idVisiteur
                        select v).Count();

            var unVisiteur = (from visiteur in mesDonnees.visiteur
                              where visiteur.id == idsupp
                              select visiteur).First();

            var LesRapports = (from rapport in mesDonnees.rapport
                               where rapport.idVisiteur == idsupp
                               select rapport).Count();


            visiteur SUPPRIMER = unVisiteur;
            if (LesRapports > 0)
            {
                MessageBox.Show("ce visiteur posséde des rapports !");
            }

            else
            {
                string message = "Voulez-vous vraiment supprimer ce visiteur ?";
                string caption = "Supprimer un visiteur";
                MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons,MessageBoxIcon.Exclamation);
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    string a = idsupp;
                    visiteur supprimer = new visiteur { id = idsupp };
                    mesDonnees.visiteur.Remove(SUPPRIMER);
                    mesDonnees.SaveChanges();
                    MessageBox.Show("Le visiteur " + a + " à bien été supprimer !");
                    this.Close();
                }

            }
        }

        private void idCombo_SelectedIndexChanged_1(object sender, EventArgs e)
        {
           
            string id = idCombo.SelectedItem.ToString();
          
            //Textbox Nom
            var getNom = (from visiteur in mesDonnees.visiteur
                          where visiteur.id == id
                          select visiteur.nom).First();

            string nom = Convert.ToString(getNom);
            txtbNom.Text = nom;
            


            //Textbox prenom 
            var getPrenom = (from visiteur in mesDonnees.visiteur
                             where visiteur.id == id
                          select visiteur.prenom).First();

            string prenom = Convert.ToString(getPrenom);
            txtbPrenom.Text = prenom;



        }

        private void idCombo_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void SupprimerVisiteur_Load_1(object sender, EventArgs e)
        {

        }
    }
}

