﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mission32020
{
    public partial class AjouterVisiteur : Form
    {
        private mission2019Entities mesDonnees;

        //ce tableau est utiliser pour les methode mdpAleatoire et loginAleatoire
        char[] TabCaractere = "AaBbCcDdEeFfgGHhiIjJkKlLmMnNoOpPQqrRSsTtUuVvWwxXYyZz".ToCharArray();
        public AjouterVisiteur(mission2019Entities mesDonnees)
        {
            InitializeComponent();
            this.mesDonnees = mesDonnees;

        }
        public void verificationEntier(KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
                e.Handled = false;
            else if (char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }
        public void verificationChar(KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
                e.Handled = true;
            else if (char.IsControl(e.KeyChar))
                e.Handled = true;
            else
                e.Handled = false;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            textBox4.Text = loginAleatoire();
            textBox5.Text = MdpAleatoire();
        }
        private string MdpAleatoire()
        {
            Random r = new Random();
            string mdp = "";
            for (int i = 0; i < 5; i++)
            {
                mdp = mdp + TabCaractere[r.Next(0, 40)].ToString();
            }
            return mdp;
        }

        private string loginAleatoire()
        {
            
            Random r = new Random();
            string login = "";
            for (int i = 0; i < 5; i++)
            {
                login = login + TabCaractere[r.Next(0,52)].ToString();
            }
            return login;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool requete = true;
            string idAjt = textBox1.Text;
            string nomAjt = textBox2.Text;
            string prenomAjt = textBox3.Text;
            string loginAjt = textBox4.Text;
            string mdpAjt = textBox5.Text;
            string adresseAjt = textBox6.Text;
            string cpAjt = textBox7.Text;
            string villeAjt = textBox8.Text;
            dateTimePicker1.MinDate = DateTime.Today;
            DateTime dateembaucheAjt = dateTimePicker1.MinDate;
            
           


            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                requete = false;
                string message = "Veuillez remplir tous les champs !";
                string caption = "Saisi vide";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
                
            }

            else if (requete)
            {

                string message = "Voulez-vous vraiment ajouter ce visiteur ?";
                string caption = "Ajouter un visiteur";
                MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);


                if (result == System.Windows.Forms.DialogResult.OK)
                {

                    string a = idAjt;
                    visiteur ajouter = new visiteur { id = idAjt, nom = nomAjt, prenom = prenomAjt, login = loginAjt, mdp = mdpAjt, adresse = adresseAjt, cp = cpAjt, ville = villeAjt, dateEmbauche = dateembaucheAjt };
                    mesDonnees.visiteur.Add(ajouter);
                    mesDonnees.SaveChanges();
                    MessageBox.Show("Le visiteur " + a + " à bien été ajouté ! \n Vos identifiants sonts :\n login : " + textBox4.Text + "\n mdp : " + textBox5.Text );
                    this.Close();
                }
            }
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void AjouterVisiteur_Load(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            verificationEntier(e);
            textBox7.MaxLength = 5;
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            verificationChar(e);
            textBox7.MaxLength = 30;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            verificationChar(e);
            textBox7.MaxLength = 30;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            verificationChar(e);
            textBox7.MaxLength = 30;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox1.MaxLength = 4;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            textBox7.MaxLength = 30;
        }
    }
    }

