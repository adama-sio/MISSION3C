﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mission32020
{
    public partial class Mission3A : Form
    {
        System.Media.SoundPlayer heussjul = new System.Media.SoundPlayer();
        System.Media.SoundPlayer gradurheuss = new System.Media.SoundPlayer();
        System.Media.SoundPlayer blanche = new System.Media.SoundPlayer();
        System.Media.SoundPlayer naps = new System.Media.SoundPlayer();
        private mission2019Entities mesDonnees;
        public Mission3A()
        {
            InitializeComponent();
            heussjul.SoundLocation = "heussjul.wav";
            gradurheuss.SoundLocation = "gradurheuss.wav";
            blanche.SoundLocation = "blanche.wav";
            naps.SoundLocation = "naps.wav";
            this.mesDonnees = new mission2019Entities();
            
           
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void rechercherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void ajouterMédecinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {         
            heussjul.Play();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            heussjul.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gradurheuss.Play();

        }

        private void dernierRapportToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            blanche.Play();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            naps.Play();
        }

        private void gestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void listeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void gérerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GererVisiteur gv = new GererVisiteur(this.mesDonnees);
            gv.Show();
        }

        private void rapportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RapportVisiteur rv = new RapportVisiteur(this.mesDonnees);
            rv.Show();
        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void rapportToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void rechercheToolStripMenuItem_Click(object sender, EventArgs e)
        {
                 }
    }
}