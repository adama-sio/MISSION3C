﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mission32020
{
   public class ResultLine
    {
        public ResultLine() { }
       

        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string IdMedecin { get; set; }
        public string Motif { get; set; }
        public string Bilan { get; set; }

        
        public string IdMedicament { get; set; }
        public string IdFamille { get; set; }
        public string Quantite { get; set; }

        

        public string Id { get; set; }
        public string date { get; set; }
        public string motif { get; set; }
        public string bilan { get; set; }
        public string idVisiteur { get; set; }
        public string nom { get; set; }







    }
}
    