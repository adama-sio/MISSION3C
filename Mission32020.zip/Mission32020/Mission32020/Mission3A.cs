﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mission32020
{
    public partial class Mission3A : Form
    {
        System.Media.SoundPlayer heussjul = new System.Media.SoundPlayer();
        System.Media.SoundPlayer gradurheuss = new System.Media.SoundPlayer();
        System.Media.SoundPlayer blanche = new System.Media.SoundPlayer();
        System.Media.SoundPlayer naps = new System.Media.SoundPlayer();
        private mission2019Entities mesDonnees;
        public Mission3A()
        {
            InitializeComponent();
            heussjul.SoundLocation = "heussjul.wav";
            gradurheuss.SoundLocation = "gradurheuss.wav";
            blanche.SoundLocation = "blanche.wav";
            naps.SoundLocation = "naps.wav";
            this.mesDonnees = new mission2019Entities();
            
           
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void rechercherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRechercheMedecin frm = new FrmRechercheMedecin(this.mesDonnees);
            frm.Show();
        }

        private void ajouterMédecinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAjoutMedecin fm = new FrmAjoutMedecin(this.mesDonnees);//
            fm.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(label2.Left < this.Width)
            {
                label2.Left = label2.Left + 2;
            }

            else
            {
                label2.Left = 1;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {         
            heussjul.Play();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            heussjul.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gradurheuss.Play();

        }

        private void dernierRapportToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // FrmRechercheRapport frr = new FrmRechercheRapport(this.mesDonnees);
            //frr.Show();
            FrmRechercheRapport ff = new FrmRechercheRapport(this.mesDonnees);
            ff.Show();
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            blanche.Play();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            naps.Play();
        }
    }
}